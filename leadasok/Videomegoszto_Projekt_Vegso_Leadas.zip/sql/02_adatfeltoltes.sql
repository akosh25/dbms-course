
-- 1. Adatok beszúrása: Felhasznalo

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user1', 'user1@email.hu', 'jelszo1', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user1.jpg', 'Ez a(z) 1. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user2', 'user2@email.hu', 'jelszo2', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user2.jpg', 'Ez a(z) 2. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user3', 'user3@email.hu', 'jelszo3', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user3.jpg', 'Ez a(z) 3. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user4', 'user4@email.hu', 'jelszo4', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user4.jpg', 'Ez a(z) 4. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user5', 'user5@email.hu', 'jelszo5', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user5.jpg', 'Ez a(z) 5. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user6', 'user6@email.hu', 'jelszo6', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user6.jpg', 'Ez a(z) 6. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user7', 'user7@email.hu', 'jelszo7', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user7.jpg', 'Ez a(z) 7. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user8', 'user8@email.hu', 'jelszo8', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user8.jpg', 'Ez a(z) 8. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user9', 'user9@email.hu', 'jelszo9', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user9.jpg', 'Ez a(z) 9. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user10', 'user10@email.hu', 'jelszo10', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user10.jpg', 'Ez a(z) 10. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user11', 'user11@email.hu', 'jelszo11', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user11.jpg', 'Ez a(z) 11. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user12', 'user12@email.hu', 'jelszo12', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user12.jpg', 'Ez a(z) 12. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user13', 'user13@email.hu', 'jelszo13', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user13.jpg', 'Ez a(z) 13. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user14', 'user14@email.hu', 'jelszo14', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user14.jpg', 'Ez a(z) 14. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user15', 'user15@email.hu', 'jelszo15', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user15.jpg', 'Ez a(z) 15. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user16', 'user16@email.hu', 'jelszo16', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user16.jpg', 'Ez a(z) 16. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user17', 'user17@email.hu', 'jelszo17', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user17.jpg', 'Ez a(z) 17. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user18', 'user18@email.hu', 'jelszo18', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user18.jpg', 'Ez a(z) 18. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user19', 'user19@email.hu', 'jelszo19', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user19.jpg', 'Ez a(z) 19. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user20', 'user20@email.hu', 'jelszo20', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user20.jpg', 'Ez a(z) 20. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user21', 'user21@email.hu', 'jelszo21', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user21.jpg', 'Ez a(z) 21. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user22', 'user22@email.hu', 'jelszo22', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user22.jpg', 'Ez a(z) 22. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user23', 'user23@email.hu', 'jelszo23', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user23.jpg', 'Ez a(z) 23. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user24', 'user24@email.hu', 'jelszo24', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user24.jpg', 'Ez a(z) 24. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user25', 'user25@email.hu', 'jelszo25', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user25.jpg', 'Ez a(z) 25. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user26', 'user26@email.hu', 'jelszo26', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user26.jpg', 'Ez a(z) 26. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user27', 'user27@email.hu', 'jelszo27', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user27.jpg', 'Ez a(z) 27. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user28', 'user28@email.hu', 'jelszo28', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user28.jpg', 'Ez a(z) 28. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user29', 'user29@email.hu', 'jelszo29', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user29.jpg', 'Ez a(z) 29. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user30', 'user30@email.hu', 'jelszo30', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user30.jpg', 'Ez a(z) 30. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user31', 'user31@email.hu', 'jelszo31', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user31.jpg', 'Ez a(z) 31. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user32', 'user32@email.hu', 'jelszo32', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user32.jpg', 'Ez a(z) 32. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user33', 'user33@email.hu', 'jelszo33', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user33.jpg', 'Ez a(z) 33. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user34', 'user34@email.hu', 'jelszo34', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user34.jpg', 'Ez a(z) 34. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user35', 'user35@email.hu', 'jelszo35', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user35.jpg', 'Ez a(z) 35. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user36', 'user36@email.hu', 'jelszo36', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user36.jpg', 'Ez a(z) 36. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user37', 'user37@email.hu', 'jelszo37', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user37.jpg', 'Ez a(z) 37. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user38', 'user38@email.hu', 'jelszo38', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user38.jpg', 'Ez a(z) 38. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user39', 'user39@email.hu', 'jelszo39', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user39.jpg', 'Ez a(z) 39. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user40', 'user40@email.hu', 'jelszo40', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user40.jpg', 'Ez a(z) 40. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user41', 'user41@email.hu', 'jelszo41', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user41.jpg', 'Ez a(z) 41. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user42', 'user42@email.hu', 'jelszo42', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user42.jpg', 'Ez a(z) 42. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user43', 'user43@email.hu', 'jelszo43', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user43.jpg', 'Ez a(z) 43. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user44', 'user44@email.hu', 'jelszo44', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user44.jpg', 'Ez a(z) 44. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user45', 'user45@email.hu', 'jelszo45', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user45.jpg', 'Ez a(z) 45. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user46', 'user46@email.hu', 'jelszo46', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user46.jpg', 'Ez a(z) 46. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user47', 'user47@email.hu', 'jelszo47', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user47.jpg', 'Ez a(z) 47. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user48', 'user48@email.hu', 'jelszo48', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user48.jpg', 'Ez a(z) 48. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user49', 'user49@email.hu', 'jelszo49', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user49.jpg', 'Ez a(z) 49. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user50', 'user50@email.hu', 'jelszo50', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user50.jpg', 'Ez a(z) 50. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user51', 'user51@email.hu', 'jelszo51', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user51.jpg', 'Ez a(z) 51. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user52', 'user52@email.hu', 'jelszo52', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user52.jpg', 'Ez a(z) 52. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user53', 'user53@email.hu', 'jelszo53', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user53.jpg', 'Ez a(z) 53. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user54', 'user54@email.hu', 'jelszo54', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user54.jpg', 'Ez a(z) 54. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user55', 'user55@email.hu', 'jelszo55', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user55.jpg', 'Ez a(z) 55. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user56', 'user56@email.hu', 'jelszo56', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user56.jpg', 'Ez a(z) 56. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user57', 'user57@email.hu', 'jelszo57', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user57.jpg', 'Ez a(z) 57. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user58', 'user58@email.hu', 'jelszo58', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user58.jpg', 'Ez a(z) 58. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user59', 'user59@email.hu', 'jelszo59', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user59.jpg', 'Ez a(z) 59. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user60', 'user60@email.hu', 'jelszo60', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user60.jpg', 'Ez a(z) 60. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user61', 'user61@email.hu', 'jelszo61', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user61.jpg', 'Ez a(z) 61. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user62', 'user62@email.hu', 'jelszo62', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user62.jpg', 'Ez a(z) 62. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user63', 'user63@email.hu', 'jelszo63', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user63.jpg', 'Ez a(z) 63. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user64', 'user64@email.hu', 'jelszo64', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user64.jpg', 'Ez a(z) 64. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user65', 'user65@email.hu', 'jelszo65', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user65.jpg', 'Ez a(z) 65. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user66', 'user66@email.hu', 'jelszo66', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user66.jpg', 'Ez a(z) 66. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user67', 'user67@email.hu', 'jelszo67', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user67.jpg', 'Ez a(z) 67. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user68', 'user68@email.hu', 'jelszo68', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user68.jpg', 'Ez a(z) 68. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user69', 'user69@email.hu', 'jelszo69', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user69.jpg', 'Ez a(z) 69. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user70', 'user70@email.hu', 'jelszo70', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user70.jpg', 'Ez a(z) 70. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user71', 'user71@email.hu', 'jelszo71', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user71.jpg', 'Ez a(z) 71. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user72', 'user72@email.hu', 'jelszo72', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user72.jpg', 'Ez a(z) 72. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user73', 'user73@email.hu', 'jelszo73', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user73.jpg', 'Ez a(z) 73. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user74', 'user74@email.hu', 'jelszo74', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user74.jpg', 'Ez a(z) 74. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user75', 'user75@email.hu', 'jelszo75', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user75.jpg', 'Ez a(z) 75. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user76', 'user76@email.hu', 'jelszo76', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user76.jpg', 'Ez a(z) 76. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user77', 'user77@email.hu', 'jelszo77', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user77.jpg', 'Ez a(z) 77. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user78', 'user78@email.hu', 'jelszo78', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user78.jpg', 'Ez a(z) 78. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user79', 'user79@email.hu', 'jelszo79', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user79.jpg', 'Ez a(z) 79. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user80', 'user80@email.hu', 'jelszo80', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user80.jpg', 'Ez a(z) 80. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user81', 'user81@email.hu', 'jelszo81', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user81.jpg', 'Ez a(z) 81. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user82', 'user82@email.hu', 'jelszo82', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user82.jpg', 'Ez a(z) 82. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user83', 'user83@email.hu', 'jelszo83', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user83.jpg', 'Ez a(z) 83. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user84', 'user84@email.hu', 'jelszo84', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user84.jpg', 'Ez a(z) 84. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user85', 'user85@email.hu', 'jelszo85', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user85.jpg', 'Ez a(z) 85. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user86', 'user86@email.hu', 'jelszo86', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user86.jpg', 'Ez a(z) 86. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user87', 'user87@email.hu', 'jelszo87', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user87.jpg', 'Ez a(z) 87. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user88', 'user88@email.hu', 'jelszo88', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user88.jpg', 'Ez a(z) 88. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user89', 'user89@email.hu', 'jelszo89', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user89.jpg', 'Ez a(z) 89. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user90', 'user90@email.hu', 'jelszo90', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user90.jpg', 'Ez a(z) 90. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user91', 'user91@email.hu', 'jelszo91', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user91.jpg', 'Ez a(z) 91. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user92', 'user92@email.hu', 'jelszo92', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user92.jpg', 'Ez a(z) 92. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user93', 'user93@email.hu', 'jelszo93', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user93.jpg', 'Ez a(z) 93. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user94', 'user94@email.hu', 'jelszo94', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user94.jpg', 'Ez a(z) 94. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user95', 'user95@email.hu', 'jelszo95', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user95.jpg', 'Ez a(z) 95. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user96', 'user96@email.hu', 'jelszo96', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user96.jpg', 'Ez a(z) 96. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user97', 'user97@email.hu', 'jelszo97', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user97.jpg', 'Ez a(z) 97. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user98', 'user98@email.hu', 'jelszo98', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user98.jpg', 'Ez a(z) 98. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user99', 'user99@email.hu', 'jelszo99', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user99.jpg', 'Ez a(z) 99. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user100', 'user100@email.hu', 'jelszo100', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user100.jpg', 'Ez a(z) 100. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user101', 'user101@email.hu', 'jelszo101', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user101.jpg', 'Ez a(z) 101. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user102', 'user102@email.hu', 'jelszo102', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user102.jpg', 'Ez a(z) 102. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user103', 'user103@email.hu', 'jelszo103', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user103.jpg', 'Ez a(z) 103. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user104', 'user104@email.hu', 'jelszo104', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user104.jpg', 'Ez a(z) 104. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user105', 'user105@email.hu', 'jelszo105', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user105.jpg', 'Ez a(z) 105. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user106', 'user106@email.hu', 'jelszo106', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user106.jpg', 'Ez a(z) 106. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user107', 'user107@email.hu', 'jelszo107', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user107.jpg', 'Ez a(z) 107. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user108', 'user108@email.hu', 'jelszo108', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user108.jpg', 'Ez a(z) 108. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user109', 'user109@email.hu', 'jelszo109', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user109.jpg', 'Ez a(z) 109. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user110', 'user110@email.hu', 'jelszo110', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user110.jpg', 'Ez a(z) 110. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user111', 'user111@email.hu', 'jelszo111', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user111.jpg', 'Ez a(z) 111. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user112', 'user112@email.hu', 'jelszo112', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user112.jpg', 'Ez a(z) 112. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user113', 'user113@email.hu', 'jelszo113', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user113.jpg', 'Ez a(z) 113. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user114', 'user114@email.hu', 'jelszo114', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user114.jpg', 'Ez a(z) 114. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user115', 'user115@email.hu', 'jelszo115', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user115.jpg', 'Ez a(z) 115. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user116', 'user116@email.hu', 'jelszo116', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user116.jpg', 'Ez a(z) 116. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user117', 'user117@email.hu', 'jelszo117', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user117.jpg', 'Ez a(z) 117. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user118', 'user118@email.hu', 'jelszo118', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user118.jpg', 'Ez a(z) 118. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user119', 'user119@email.hu', 'jelszo119', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user119.jpg', 'Ez a(z) 119. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user120', 'user120@email.hu', 'jelszo120', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user120.jpg', 'Ez a(z) 120. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user121', 'user121@email.hu', 'jelszo121', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user121.jpg', 'Ez a(z) 121. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user122', 'user122@email.hu', 'jelszo122', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user122.jpg', 'Ez a(z) 122. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user123', 'user123@email.hu', 'jelszo123', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user123.jpg', 'Ez a(z) 123. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user124', 'user124@email.hu', 'jelszo124', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user124.jpg', 'Ez a(z) 124. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user125', 'user125@email.hu', 'jelszo125', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user125.jpg', 'Ez a(z) 125. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user126', 'user126@email.hu', 'jelszo126', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user126.jpg', 'Ez a(z) 126. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user127', 'user127@email.hu', 'jelszo127', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user127.jpg', 'Ez a(z) 127. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user128', 'user128@email.hu', 'jelszo128', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user128.jpg', 'Ez a(z) 128. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user129', 'user129@email.hu', 'jelszo129', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user129.jpg', 'Ez a(z) 129. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user130', 'user130@email.hu', 'jelszo130', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user130.jpg', 'Ez a(z) 130. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user131', 'user131@email.hu', 'jelszo131', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user131.jpg', 'Ez a(z) 131. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user132', 'user132@email.hu', 'jelszo132', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user132.jpg', 'Ez a(z) 132. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user133', 'user133@email.hu', 'jelszo133', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user133.jpg', 'Ez a(z) 133. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user134', 'user134@email.hu', 'jelszo134', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user134.jpg', 'Ez a(z) 134. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user135', 'user135@email.hu', 'jelszo135', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user135.jpg', 'Ez a(z) 135. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user136', 'user136@email.hu', 'jelszo136', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user136.jpg', 'Ez a(z) 136. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user137', 'user137@email.hu', 'jelszo137', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user137.jpg', 'Ez a(z) 137. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user138', 'user138@email.hu', 'jelszo138', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user138.jpg', 'Ez a(z) 138. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user139', 'user139@email.hu', 'jelszo139', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user139.jpg', 'Ez a(z) 139. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user140', 'user140@email.hu', 'jelszo140', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user140.jpg', 'Ez a(z) 140. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user141', 'user141@email.hu', 'jelszo141', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user141.jpg', 'Ez a(z) 141. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user142', 'user142@email.hu', 'jelszo142', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user142.jpg', 'Ez a(z) 142. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user143', 'user143@email.hu', 'jelszo143', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user143.jpg', 'Ez a(z) 143. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user144', 'user144@email.hu', 'jelszo144', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user144.jpg', 'Ez a(z) 144. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user145', 'user145@email.hu', 'jelszo145', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user145.jpg', 'Ez a(z) 145. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user146', 'user146@email.hu', 'jelszo146', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user146.jpg', 'Ez a(z) 146. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user147', 'user147@email.hu', 'jelszo147', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user147.jpg', 'Ez a(z) 147. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user148', 'user148@email.hu', 'jelszo148', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user148.jpg', 'Ez a(z) 148. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user149', 'user149@email.hu', 'jelszo149', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user149.jpg', 'Ez a(z) 149. felhasználó bemutatkozása.'
);

INSERT INTO Felhasznalo (
    felhasznalo_id, felhasznalonev, email, jelszo, szerepkor,
    regisztracio_idopont, utolso_bejelentkezes, profilkep_url, bio
) VALUES (
    felhasznalo_seq.NEXTVAL, 'user150', 'user150@email.hu', 'jelszo150', 'user',
    SYSTIMESTAMP, SYSTIMESTAMP, 'https://example.com/user150.jpg', 'Ez a(z) 150. felhasználó bemutatkozása.'
);


-- 2. Adatok beszúrása: Kategoria
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 1', 'Ez a(z) 1. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 2', 'Ez a(z) 2. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 3', 'Ez a(z) 3. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 4', 'Ez a(z) 4. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 5', 'Ez a(z) 5. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 6', 'Ez a(z) 6. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 7', 'Ez a(z) 7. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 8', 'Ez a(z) 8. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 9', 'Ez a(z) 9. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 10', 'Ez a(z) 10. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 11', 'Ez a(z) 11. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 12', 'Ez a(z) 12. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 13', 'Ez a(z) 13. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 14', 'Ez a(z) 14. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 15', 'Ez a(z) 15. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 16', 'Ez a(z) 16. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 17', 'Ez a(z) 17. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 18', 'Ez a(z) 18. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 19', 'Ez a(z) 19. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 20', 'Ez a(z) 20. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 21', 'Ez a(z) 21. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 22', 'Ez a(z) 22. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 23', 'Ez a(z) 23. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 24', 'Ez a(z) 24. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 25', 'Ez a(z) 25. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 26', 'Ez a(z) 26. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 27', 'Ez a(z) 27. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 28', 'Ez a(z) 28. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 29', 'Ez a(z) 29. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 30', 'Ez a(z) 30. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 31', 'Ez a(z) 31. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 32', 'Ez a(z) 32. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 33', 'Ez a(z) 33. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 34', 'Ez a(z) 34. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 35', 'Ez a(z) 35. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 36', 'Ez a(z) 36. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 37', 'Ez a(z) 37. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 38', 'Ez a(z) 38. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 39', 'Ez a(z) 39. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 40', 'Ez a(z) 40. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 41', 'Ez a(z) 41. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 42', 'Ez a(z) 42. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 43', 'Ez a(z) 43. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 44', 'Ez a(z) 44. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 45', 'Ez a(z) 45. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 46', 'Ez a(z) 46. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 47', 'Ez a(z) 47. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 48', 'Ez a(z) 48. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 49', 'Ez a(z) 49. kategória leírása');
INSERT INTO Kategoria (kategoria_id, nev, leiras) VALUES (kategoria_seq.NEXTVAL, 'Kategória 50', 'Ez a(z) 50. kategória leírása');


-- 3. Adatok beszúrása: Video
INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 1', 'Leírás a(z) 1. videóhoz', SYSTIMESTAMP, 2, 301, 0, 'https://video.hu/video_1.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 2', 'Leírás a(z) 2. videóhoz', SYSTIMESTAMP, 3, 302, 1, 'https://video.hu/video_2.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 3', 'Leírás a(z) 3. videóhoz', SYSTIMESTAMP, 4, 303, 0, 'https://video.hu/video_3.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 4', 'Leírás a(z) 4. videóhoz', SYSTIMESTAMP, 5, 304, 1, 'https://video.hu/video_4.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 5', 'Leírás a(z) 5. videóhoz', SYSTIMESTAMP, 6, 305, 0, 'https://video.hu/video_5.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 6', 'Leírás a(z) 6. videóhoz', SYSTIMESTAMP, 7, 306, 1, 'https://video.hu/video_6.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 7', 'Leírás a(z) 7. videóhoz', SYSTIMESTAMP, 8, 307, 0, 'https://video.hu/video_7.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 8', 'Leírás a(z) 8. videóhoz', SYSTIMESTAMP, 9, 308, 1, 'https://video.hu/video_8.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 9', 'Leírás a(z) 9. videóhoz', SYSTIMESTAMP, 10, 309, 0, 'https://video.hu/video_9.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 10', 'Leírás a(z) 10. videóhoz', SYSTIMESTAMP, 11, 310, 1, 'https://video.hu/video_10.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 11', 'Leírás a(z) 11. videóhoz', SYSTIMESTAMP, 12, 311, 0, 'https://video.hu/video_11.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 12', 'Leírás a(z) 12. videóhoz', SYSTIMESTAMP, 13, 312, 1, 'https://video.hu/video_12.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 13', 'Leírás a(z) 13. videóhoz', SYSTIMESTAMP, 14, 313, 0, 'https://video.hu/video_13.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 14', 'Leírás a(z) 14. videóhoz', SYSTIMESTAMP, 15, 314, 1, 'https://video.hu/video_14.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 15', 'Leírás a(z) 15. videóhoz', SYSTIMESTAMP, 16, 315, 0, 'https://video.hu/video_15.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 16', 'Leírás a(z) 16. videóhoz', SYSTIMESTAMP, 17, 316, 1, 'https://video.hu/video_16.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 17', 'Leírás a(z) 17. videóhoz', SYSTIMESTAMP, 18, 317, 0, 'https://video.hu/video_17.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 18', 'Leírás a(z) 18. videóhoz', SYSTIMESTAMP, 19, 318, 1, 'https://video.hu/video_18.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 19', 'Leírás a(z) 19. videóhoz', SYSTIMESTAMP, 20, 319, 0, 'https://video.hu/video_19.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 20', 'Leírás a(z) 20. videóhoz', SYSTIMESTAMP, 21, 320, 1, 'https://video.hu/video_20.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 21', 'Leírás a(z) 21. videóhoz', SYSTIMESTAMP, 22, 321, 0, 'https://video.hu/video_21.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 22', 'Leírás a(z) 22. videóhoz', SYSTIMESTAMP, 23, 322, 1, 'https://video.hu/video_22.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 23', 'Leírás a(z) 23. videóhoz', SYSTIMESTAMP, 24, 323, 0, 'https://video.hu/video_23.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 24', 'Leírás a(z) 24. videóhoz', SYSTIMESTAMP, 25, 324, 1, 'https://video.hu/video_24.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 25', 'Leírás a(z) 25. videóhoz', SYSTIMESTAMP, 26, 325, 0, 'https://video.hu/video_25.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 26', 'Leírás a(z) 26. videóhoz', SYSTIMESTAMP, 27, 326, 1, 'https://video.hu/video_26.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 27', 'Leírás a(z) 27. videóhoz', SYSTIMESTAMP, 28, 327, 0, 'https://video.hu/video_27.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 28', 'Leírás a(z) 28. videóhoz', SYSTIMESTAMP, 29, 328, 1, 'https://video.hu/video_28.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 29', 'Leírás a(z) 29. videóhoz', SYSTIMESTAMP, 30, 329, 0, 'https://video.hu/video_29.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 30', 'Leírás a(z) 30. videóhoz', SYSTIMESTAMP, 31, 330, 1, 'https://video.hu/video_30.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 31', 'Leírás a(z) 31. videóhoz', SYSTIMESTAMP, 32, 331, 0, 'https://video.hu/video_31.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 32', 'Leírás a(z) 32. videóhoz', SYSTIMESTAMP, 33, 332, 1, 'https://video.hu/video_32.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 33', 'Leírás a(z) 33. videóhoz', SYSTIMESTAMP, 34, 333, 0, 'https://video.hu/video_33.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 34', 'Leírás a(z) 34. videóhoz', SYSTIMESTAMP, 35, 334, 1, 'https://video.hu/video_34.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 35', 'Leírás a(z) 35. videóhoz', SYSTIMESTAMP, 36, 335, 0, 'https://video.hu/video_35.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 36', 'Leírás a(z) 36. videóhoz', SYSTIMESTAMP, 37, 336, 1, 'https://video.hu/video_36.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 37', 'Leírás a(z) 37. videóhoz', SYSTIMESTAMP, 38, 337, 0, 'https://video.hu/video_37.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 38', 'Leírás a(z) 38. videóhoz', SYSTIMESTAMP, 39, 338, 1, 'https://video.hu/video_38.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 39', 'Leírás a(z) 39. videóhoz', SYSTIMESTAMP, 40, 339, 0, 'https://video.hu/video_39.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 40', 'Leírás a(z) 40. videóhoz', SYSTIMESTAMP, 41, 340, 1, 'https://video.hu/video_40.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 41', 'Leírás a(z) 41. videóhoz', SYSTIMESTAMP, 42, 341, 0, 'https://video.hu/video_41.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 42', 'Leírás a(z) 42. videóhoz', SYSTIMESTAMP, 43, 342, 1, 'https://video.hu/video_42.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 43', 'Leírás a(z) 43. videóhoz', SYSTIMESTAMP, 44, 343, 0, 'https://video.hu/video_43.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 44', 'Leírás a(z) 44. videóhoz', SYSTIMESTAMP, 45, 344, 1, 'https://video.hu/video_44.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 45', 'Leírás a(z) 45. videóhoz', SYSTIMESTAMP, 46, 345, 0, 'https://video.hu/video_45.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 46', 'Leírás a(z) 46. videóhoz', SYSTIMESTAMP, 47, 346, 1, 'https://video.hu/video_46.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 47', 'Leírás a(z) 47. videóhoz', SYSTIMESTAMP, 48, 347, 0, 'https://video.hu/video_47.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 48', 'Leírás a(z) 48. videóhoz', SYSTIMESTAMP, 49, 348, 1, 'https://video.hu/video_48.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 49', 'Leírás a(z) 49. videóhoz', SYSTIMESTAMP, 50, 349, 0, 'https://video.hu/video_49.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 50', 'Leírás a(z) 50. videóhoz', SYSTIMESTAMP, 51, 350, 1, 'https://video.hu/video_50.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 51', 'Leírás a(z) 51. videóhoz', SYSTIMESTAMP, 52, 351, 0, 'https://video.hu/video_51.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 52', 'Leírás a(z) 52. videóhoz', SYSTIMESTAMP, 53, 352, 1, 'https://video.hu/video_52.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 53', 'Leírás a(z) 53. videóhoz', SYSTIMESTAMP, 54, 353, 0, 'https://video.hu/video_53.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 54', 'Leírás a(z) 54. videóhoz', SYSTIMESTAMP, 55, 354, 1, 'https://video.hu/video_54.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 55', 'Leírás a(z) 55. videóhoz', SYSTIMESTAMP, 56, 355, 0, 'https://video.hu/video_55.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 56', 'Leírás a(z) 56. videóhoz', SYSTIMESTAMP, 57, 356, 1, 'https://video.hu/video_56.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 57', 'Leírás a(z) 57. videóhoz', SYSTIMESTAMP, 58, 357, 0, 'https://video.hu/video_57.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 58', 'Leírás a(z) 58. videóhoz', SYSTIMESTAMP, 59, 358, 1, 'https://video.hu/video_58.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 59', 'Leírás a(z) 59. videóhoz', SYSTIMESTAMP, 60, 359, 0, 'https://video.hu/video_59.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 60', 'Leírás a(z) 60. videóhoz', SYSTIMESTAMP, 61, 360, 1, 'https://video.hu/video_60.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 61', 'Leírás a(z) 61. videóhoz', SYSTIMESTAMP, 62, 361, 0, 'https://video.hu/video_61.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 62', 'Leírás a(z) 62. videóhoz', SYSTIMESTAMP, 63, 362, 1, 'https://video.hu/video_62.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 63', 'Leírás a(z) 63. videóhoz', SYSTIMESTAMP, 64, 363, 0, 'https://video.hu/video_63.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 64', 'Leírás a(z) 64. videóhoz', SYSTIMESTAMP, 65, 364, 1, 'https://video.hu/video_64.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 65', 'Leírás a(z) 65. videóhoz', SYSTIMESTAMP, 66, 365, 0, 'https://video.hu/video_65.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 66', 'Leírás a(z) 66. videóhoz', SYSTIMESTAMP, 67, 366, 1, 'https://video.hu/video_66.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 67', 'Leírás a(z) 67. videóhoz', SYSTIMESTAMP, 68, 367, 0, 'https://video.hu/video_67.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 68', 'Leírás a(z) 68. videóhoz', SYSTIMESTAMP, 69, 368, 1, 'https://video.hu/video_68.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 69', 'Leírás a(z) 69. videóhoz', SYSTIMESTAMP, 70, 369, 0, 'https://video.hu/video_69.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 70', 'Leírás a(z) 70. videóhoz', SYSTIMESTAMP, 71, 370, 1, 'https://video.hu/video_70.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 71', 'Leírás a(z) 71. videóhoz', SYSTIMESTAMP, 72, 371, 0, 'https://video.hu/video_71.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 72', 'Leírás a(z) 72. videóhoz', SYSTIMESTAMP, 73, 372, 1, 'https://video.hu/video_72.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 73', 'Leírás a(z) 73. videóhoz', SYSTIMESTAMP, 74, 373, 0, 'https://video.hu/video_73.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 74', 'Leírás a(z) 74. videóhoz', SYSTIMESTAMP, 75, 374, 1, 'https://video.hu/video_74.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 75', 'Leírás a(z) 75. videóhoz', SYSTIMESTAMP, 76, 375, 0, 'https://video.hu/video_75.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 76', 'Leírás a(z) 76. videóhoz', SYSTIMESTAMP, 77, 376, 1, 'https://video.hu/video_76.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 77', 'Leírás a(z) 77. videóhoz', SYSTIMESTAMP, 78, 377, 0, 'https://video.hu/video_77.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 78', 'Leírás a(z) 78. videóhoz', SYSTIMESTAMP, 79, 378, 1, 'https://video.hu/video_78.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 79', 'Leírás a(z) 79. videóhoz', SYSTIMESTAMP, 80, 379, 0, 'https://video.hu/video_79.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 80', 'Leírás a(z) 80. videóhoz', SYSTIMESTAMP, 81, 380, 1, 'https://video.hu/video_80.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 81', 'Leírás a(z) 81. videóhoz', SYSTIMESTAMP, 82, 381, 0, 'https://video.hu/video_81.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 82', 'Leírás a(z) 82. videóhoz', SYSTIMESTAMP, 83, 382, 1, 'https://video.hu/video_82.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 83', 'Leírás a(z) 83. videóhoz', SYSTIMESTAMP, 84, 383, 0, 'https://video.hu/video_83.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 84', 'Leírás a(z) 84. videóhoz', SYSTIMESTAMP, 85, 384, 1, 'https://video.hu/video_84.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 85', 'Leírás a(z) 85. videóhoz', SYSTIMESTAMP, 86, 385, 0, 'https://video.hu/video_85.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 86', 'Leírás a(z) 86. videóhoz', SYSTIMESTAMP, 87, 386, 1, 'https://video.hu/video_86.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 87', 'Leírás a(z) 87. videóhoz', SYSTIMESTAMP, 88, 387, 0, 'https://video.hu/video_87.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 88', 'Leírás a(z) 88. videóhoz', SYSTIMESTAMP, 89, 388, 1, 'https://video.hu/video_88.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 89', 'Leírás a(z) 89. videóhoz', SYSTIMESTAMP, 90, 389, 0, 'https://video.hu/video_89.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 90', 'Leírás a(z) 90. videóhoz', SYSTIMESTAMP, 91, 390, 1, 'https://video.hu/video_90.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 91', 'Leírás a(z) 91. videóhoz', SYSTIMESTAMP, 92, 391, 0, 'https://video.hu/video_91.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 92', 'Leírás a(z) 92. videóhoz', SYSTIMESTAMP, 93, 392, 1, 'https://video.hu/video_92.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 93', 'Leírás a(z) 93. videóhoz', SYSTIMESTAMP, 94, 393, 0, 'https://video.hu/video_93.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 94', 'Leírás a(z) 94. videóhoz', SYSTIMESTAMP, 95, 394, 1, 'https://video.hu/video_94.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 95', 'Leírás a(z) 95. videóhoz', SYSTIMESTAMP, 96, 395, 0, 'https://video.hu/video_95.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 96', 'Leírás a(z) 96. videóhoz', SYSTIMESTAMP, 97, 396, 1, 'https://video.hu/video_96.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 97', 'Leírás a(z) 97. videóhoz', SYSTIMESTAMP, 98, 397, 0, 'https://video.hu/video_97.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 98', 'Leírás a(z) 98. videóhoz', SYSTIMESTAMP, 99, 398, 1, 'https://video.hu/video_98.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 99', 'Leírás a(z) 99. videóhoz', SYSTIMESTAMP, 100, 399, 0, 'https://video.hu/video_99.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 100', 'Leírás a(z) 100. videóhoz', SYSTIMESTAMP, 101, 400, 1, 'https://video.hu/video_100.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 101', 'Leírás a(z) 101. videóhoz', SYSTIMESTAMP, 102, 401, 0, 'https://video.hu/video_101.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 102', 'Leírás a(z) 102. videóhoz', SYSTIMESTAMP, 103, 402, 1, 'https://video.hu/video_102.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 103', 'Leírás a(z) 103. videóhoz', SYSTIMESTAMP, 104, 403, 0, 'https://video.hu/video_103.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 104', 'Leírás a(z) 104. videóhoz', SYSTIMESTAMP, 105, 404, 1, 'https://video.hu/video_104.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 105', 'Leírás a(z) 105. videóhoz', SYSTIMESTAMP, 106, 405, 0, 'https://video.hu/video_105.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 106', 'Leírás a(z) 106. videóhoz', SYSTIMESTAMP, 107, 406, 1, 'https://video.hu/video_106.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 107', 'Leírás a(z) 107. videóhoz', SYSTIMESTAMP, 108, 407, 0, 'https://video.hu/video_107.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 108', 'Leírás a(z) 108. videóhoz', SYSTIMESTAMP, 109, 408, 1, 'https://video.hu/video_108.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 109', 'Leírás a(z) 109. videóhoz', SYSTIMESTAMP, 110, 409, 0, 'https://video.hu/video_109.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 110', 'Leírás a(z) 110. videóhoz', SYSTIMESTAMP, 111, 410, 1, 'https://video.hu/video_110.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 111', 'Leírás a(z) 111. videóhoz', SYSTIMESTAMP, 112, 411, 0, 'https://video.hu/video_111.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 112', 'Leírás a(z) 112. videóhoz', SYSTIMESTAMP, 113, 412, 1, 'https://video.hu/video_112.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 113', 'Leírás a(z) 113. videóhoz', SYSTIMESTAMP, 114, 413, 0, 'https://video.hu/video_113.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 114', 'Leírás a(z) 114. videóhoz', SYSTIMESTAMP, 115, 414, 1, 'https://video.hu/video_114.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 115', 'Leírás a(z) 115. videóhoz', SYSTIMESTAMP, 116, 415, 0, 'https://video.hu/video_115.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 116', 'Leírás a(z) 116. videóhoz', SYSTIMESTAMP, 117, 416, 1, 'https://video.hu/video_116.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 117', 'Leírás a(z) 117. videóhoz', SYSTIMESTAMP, 118, 417, 0, 'https://video.hu/video_117.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 118', 'Leírás a(z) 118. videóhoz', SYSTIMESTAMP, 119, 418, 1, 'https://video.hu/video_118.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 119', 'Leírás a(z) 119. videóhoz', SYSTIMESTAMP, 120, 419, 0, 'https://video.hu/video_119.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 120', 'Leírás a(z) 120. videóhoz', SYSTIMESTAMP, 121, 420, 1, 'https://video.hu/video_120.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 121', 'Leírás a(z) 121. videóhoz', SYSTIMESTAMP, 122, 421, 0, 'https://video.hu/video_121.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 122', 'Leírás a(z) 122. videóhoz', SYSTIMESTAMP, 123, 422, 1, 'https://video.hu/video_122.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 123', 'Leírás a(z) 123. videóhoz', SYSTIMESTAMP, 124, 423, 0, 'https://video.hu/video_123.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 124', 'Leírás a(z) 124. videóhoz', SYSTIMESTAMP, 125, 424, 1, 'https://video.hu/video_124.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 125', 'Leírás a(z) 125. videóhoz', SYSTIMESTAMP, 126, 425, 0, 'https://video.hu/video_125.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 126', 'Leírás a(z) 126. videóhoz', SYSTIMESTAMP, 127, 426, 1, 'https://video.hu/video_126.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 127', 'Leírás a(z) 127. videóhoz', SYSTIMESTAMP, 128, 427, 0, 'https://video.hu/video_127.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 128', 'Leírás a(z) 128. videóhoz', SYSTIMESTAMP, 129, 428, 1, 'https://video.hu/video_128.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 129', 'Leírás a(z) 129. videóhoz', SYSTIMESTAMP, 130, 429, 0, 'https://video.hu/video_129.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 130', 'Leírás a(z) 130. videóhoz', SYSTIMESTAMP, 131, 430, 1, 'https://video.hu/video_130.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 131', 'Leírás a(z) 131. videóhoz', SYSTIMESTAMP, 132, 431, 0, 'https://video.hu/video_131.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 132', 'Leírás a(z) 132. videóhoz', SYSTIMESTAMP, 133, 432, 1, 'https://video.hu/video_132.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 133', 'Leírás a(z) 133. videóhoz', SYSTIMESTAMP, 134, 433, 0, 'https://video.hu/video_133.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 134', 'Leírás a(z) 134. videóhoz', SYSTIMESTAMP, 135, 434, 1, 'https://video.hu/video_134.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 135', 'Leírás a(z) 135. videóhoz', SYSTIMESTAMP, 136, 435, 0, 'https://video.hu/video_135.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 136', 'Leírás a(z) 136. videóhoz', SYSTIMESTAMP, 137, 436, 1, 'https://video.hu/video_136.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 137', 'Leírás a(z) 137. videóhoz', SYSTIMESTAMP, 138, 437, 0, 'https://video.hu/video_137.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 138', 'Leírás a(z) 138. videóhoz', SYSTIMESTAMP, 139, 438, 1, 'https://video.hu/video_138.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 139', 'Leírás a(z) 139. videóhoz', SYSTIMESTAMP, 140, 439, 0, 'https://video.hu/video_139.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 140', 'Leírás a(z) 140. videóhoz', SYSTIMESTAMP, 141, 440, 1, 'https://video.hu/video_140.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 141', 'Leírás a(z) 141. videóhoz', SYSTIMESTAMP, 142, 441, 0, 'https://video.hu/video_141.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 142', 'Leírás a(z) 142. videóhoz', SYSTIMESTAMP, 143, 442, 1, 'https://video.hu/video_142.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 143', 'Leírás a(z) 143. videóhoz', SYSTIMESTAMP, 144, 443, 0, 'https://video.hu/video_143.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 144', 'Leírás a(z) 144. videóhoz', SYSTIMESTAMP, 145, 444, 1, 'https://video.hu/video_144.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 145', 'Leírás a(z) 145. videóhoz', SYSTIMESTAMP, 146, 445, 0, 'https://video.hu/video_145.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 146', 'Leírás a(z) 146. videóhoz', SYSTIMESTAMP, 147, 446, 1, 'https://video.hu/video_146.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 147', 'Leírás a(z) 147. videóhoz', SYSTIMESTAMP, 148, 447, 0, 'https://video.hu/video_147.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 148', 'Leírás a(z) 148. videóhoz', SYSTIMESTAMP, 149, 448, 1, 'https://video.hu/video_148.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 149', 'Leírás a(z) 149. videóhoz', SYSTIMESTAMP, 150, 449, 0, 'https://video.hu/video_149.mp4'
);

INSERT INTO Video (
    video_id, cim, leiras, feltoltes_datum, felhasznalo_id, hossz, is_short, video_url
) VALUES (
    video_seq.NEXTVAL, 'Videó 150', 'Leírás a(z) 150. videóhoz', SYSTIMESTAMP, 1, 450, 1, 'https://video.hu/video_150.mp4'
);


-- 4. Adatok beszúrása: VideoMetadata
INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_1.mp4', 'https://video.hu/thumb_1.jpg', '<iframe src="https://video.hu/video_1.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_2.mp4', 'https://video.hu/thumb_2.jpg', '<iframe src="https://video.hu/video_2.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_3.mp4', 'https://video.hu/thumb_3.jpg', '<iframe src="https://video.hu/video_3.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_4.mp4', 'https://video.hu/thumb_4.jpg', '<iframe src="https://video.hu/video_4.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_5.mp4', 'https://video.hu/thumb_5.jpg', '<iframe src="https://video.hu/video_5.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_6.mp4', 'https://video.hu/thumb_6.jpg', '<iframe src="https://video.hu/video_6.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_7.mp4', 'https://video.hu/thumb_7.jpg', '<iframe src="https://video.hu/video_7.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_8.mp4', 'https://video.hu/thumb_8.jpg', '<iframe src="https://video.hu/video_8.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_9.mp4', 'https://video.hu/thumb_9.jpg', '<iframe src="https://video.hu/video_9.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_10.mp4', 'https://video.hu/thumb_10.jpg', '<iframe src="https://video.hu/video_10.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_11.mp4', 'https://video.hu/thumb_11.jpg', '<iframe src="https://video.hu/video_11.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_12.mp4', 'https://video.hu/thumb_12.jpg', '<iframe src="https://video.hu/video_12.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_13.mp4', 'https://video.hu/thumb_13.jpg', '<iframe src="https://video.hu/video_13.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_14.mp4', 'https://video.hu/thumb_14.jpg', '<iframe src="https://video.hu/video_14.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_15.mp4', 'https://video.hu/thumb_15.jpg', '<iframe src="https://video.hu/video_15.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_16.mp4', 'https://video.hu/thumb_16.jpg', '<iframe src="https://video.hu/video_16.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_17.mp4', 'https://video.hu/thumb_17.jpg', '<iframe src="https://video.hu/video_17.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_18.mp4', 'https://video.hu/thumb_18.jpg', '<iframe src="https://video.hu/video_18.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_19.mp4', 'https://video.hu/thumb_19.jpg', '<iframe src="https://video.hu/video_19.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_20.mp4', 'https://video.hu/thumb_20.jpg', '<iframe src="https://video.hu/video_20.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_21.mp4', 'https://video.hu/thumb_21.jpg', '<iframe src="https://video.hu/video_21.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_22.mp4', 'https://video.hu/thumb_22.jpg', '<iframe src="https://video.hu/video_22.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_23.mp4', 'https://video.hu/thumb_23.jpg', '<iframe src="https://video.hu/video_23.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_24.mp4', 'https://video.hu/thumb_24.jpg', '<iframe src="https://video.hu/video_24.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_25.mp4', 'https://video.hu/thumb_25.jpg', '<iframe src="https://video.hu/video_25.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_26.mp4', 'https://video.hu/thumb_26.jpg', '<iframe src="https://video.hu/video_26.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_27.mp4', 'https://video.hu/thumb_27.jpg', '<iframe src="https://video.hu/video_27.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_28.mp4', 'https://video.hu/thumb_28.jpg', '<iframe src="https://video.hu/video_28.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_29.mp4', 'https://video.hu/thumb_29.jpg', '<iframe src="https://video.hu/video_29.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_30.mp4', 'https://video.hu/thumb_30.jpg', '<iframe src="https://video.hu/video_30.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_31.mp4', 'https://video.hu/thumb_31.jpg', '<iframe src="https://video.hu/video_31.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_32.mp4', 'https://video.hu/thumb_32.jpg', '<iframe src="https://video.hu/video_32.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_33.mp4', 'https://video.hu/thumb_33.jpg', '<iframe src="https://video.hu/video_33.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_34.mp4', 'https://video.hu/thumb_34.jpg', '<iframe src="https://video.hu/video_34.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_35.mp4', 'https://video.hu/thumb_35.jpg', '<iframe src="https://video.hu/video_35.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_36.mp4', 'https://video.hu/thumb_36.jpg', '<iframe src="https://video.hu/video_36.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_37.mp4', 'https://video.hu/thumb_37.jpg', '<iframe src="https://video.hu/video_37.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_38.mp4', 'https://video.hu/thumb_38.jpg', '<iframe src="https://video.hu/video_38.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_39.mp4', 'https://video.hu/thumb_39.jpg', '<iframe src="https://video.hu/video_39.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_40.mp4', 'https://video.hu/thumb_40.jpg', '<iframe src="https://video.hu/video_40.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_41.mp4', 'https://video.hu/thumb_41.jpg', '<iframe src="https://video.hu/video_41.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_42.mp4', 'https://video.hu/thumb_42.jpg', '<iframe src="https://video.hu/video_42.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_43.mp4', 'https://video.hu/thumb_43.jpg', '<iframe src="https://video.hu/video_43.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_44.mp4', 'https://video.hu/thumb_44.jpg', '<iframe src="https://video.hu/video_44.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_45.mp4', 'https://video.hu/thumb_45.jpg', '<iframe src="https://video.hu/video_45.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_46.mp4', 'https://video.hu/thumb_46.jpg', '<iframe src="https://video.hu/video_46.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_47.mp4', 'https://video.hu/thumb_47.jpg', '<iframe src="https://video.hu/video_47.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_48.mp4', 'https://video.hu/thumb_48.jpg', '<iframe src="https://video.hu/video_48.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_49.mp4', 'https://video.hu/thumb_49.jpg', '<iframe src="https://video.hu/video_49.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_50.mp4', 'https://video.hu/thumb_50.jpg', '<iframe src="https://video.hu/video_50.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_51.mp4', 'https://video.hu/thumb_51.jpg', '<iframe src="https://video.hu/video_51.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_52.mp4', 'https://video.hu/thumb_52.jpg', '<iframe src="https://video.hu/video_52.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_53.mp4', 'https://video.hu/thumb_53.jpg', '<iframe src="https://video.hu/video_53.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_54.mp4', 'https://video.hu/thumb_54.jpg', '<iframe src="https://video.hu/video_54.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_55.mp4', 'https://video.hu/thumb_55.jpg', '<iframe src="https://video.hu/video_55.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_56.mp4', 'https://video.hu/thumb_56.jpg', '<iframe src="https://video.hu/video_56.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_57.mp4', 'https://video.hu/thumb_57.jpg', '<iframe src="https://video.hu/video_57.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_58.mp4', 'https://video.hu/thumb_58.jpg', '<iframe src="https://video.hu/video_58.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_59.mp4', 'https://video.hu/thumb_59.jpg', '<iframe src="https://video.hu/video_59.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_60.mp4', 'https://video.hu/thumb_60.jpg', '<iframe src="https://video.hu/video_60.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_61.mp4', 'https://video.hu/thumb_61.jpg', '<iframe src="https://video.hu/video_61.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_62.mp4', 'https://video.hu/thumb_62.jpg', '<iframe src="https://video.hu/video_62.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_63.mp4', 'https://video.hu/thumb_63.jpg', '<iframe src="https://video.hu/video_63.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_64.mp4', 'https://video.hu/thumb_64.jpg', '<iframe src="https://video.hu/video_64.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_65.mp4', 'https://video.hu/thumb_65.jpg', '<iframe src="https://video.hu/video_65.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_66.mp4', 'https://video.hu/thumb_66.jpg', '<iframe src="https://video.hu/video_66.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_67.mp4', 'https://video.hu/thumb_67.jpg', '<iframe src="https://video.hu/video_67.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_68.mp4', 'https://video.hu/thumb_68.jpg', '<iframe src="https://video.hu/video_68.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_69.mp4', 'https://video.hu/thumb_69.jpg', '<iframe src="https://video.hu/video_69.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_70.mp4', 'https://video.hu/thumb_70.jpg', '<iframe src="https://video.hu/video_70.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_71.mp4', 'https://video.hu/thumb_71.jpg', '<iframe src="https://video.hu/video_71.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_72.mp4', 'https://video.hu/thumb_72.jpg', '<iframe src="https://video.hu/video_72.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_73.mp4', 'https://video.hu/thumb_73.jpg', '<iframe src="https://video.hu/video_73.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_74.mp4', 'https://video.hu/thumb_74.jpg', '<iframe src="https://video.hu/video_74.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_75.mp4', 'https://video.hu/thumb_75.jpg', '<iframe src="https://video.hu/video_75.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_76.mp4', 'https://video.hu/thumb_76.jpg', '<iframe src="https://video.hu/video_76.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_77.mp4', 'https://video.hu/thumb_77.jpg', '<iframe src="https://video.hu/video_77.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_78.mp4', 'https://video.hu/thumb_78.jpg', '<iframe src="https://video.hu/video_78.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_79.mp4', 'https://video.hu/thumb_79.jpg', '<iframe src="https://video.hu/video_79.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_80.mp4', 'https://video.hu/thumb_80.jpg', '<iframe src="https://video.hu/video_80.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_81.mp4', 'https://video.hu/thumb_81.jpg', '<iframe src="https://video.hu/video_81.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_82.mp4', 'https://video.hu/thumb_82.jpg', '<iframe src="https://video.hu/video_82.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_83.mp4', 'https://video.hu/thumb_83.jpg', '<iframe src="https://video.hu/video_83.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_84.mp4', 'https://video.hu/thumb_84.jpg', '<iframe src="https://video.hu/video_84.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_85.mp4', 'https://video.hu/thumb_85.jpg', '<iframe src="https://video.hu/video_85.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_86.mp4', 'https://video.hu/thumb_86.jpg', '<iframe src="https://video.hu/video_86.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_87.mp4', 'https://video.hu/thumb_87.jpg', '<iframe src="https://video.hu/video_87.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_88.mp4', 'https://video.hu/thumb_88.jpg', '<iframe src="https://video.hu/video_88.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_89.mp4', 'https://video.hu/thumb_89.jpg', '<iframe src="https://video.hu/video_89.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_90.mp4', 'https://video.hu/thumb_90.jpg', '<iframe src="https://video.hu/video_90.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_91.mp4', 'https://video.hu/thumb_91.jpg', '<iframe src="https://video.hu/video_91.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_92.mp4', 'https://video.hu/thumb_92.jpg', '<iframe src="https://video.hu/video_92.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_93.mp4', 'https://video.hu/thumb_93.jpg', '<iframe src="https://video.hu/video_93.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_94.mp4', 'https://video.hu/thumb_94.jpg', '<iframe src="https://video.hu/video_94.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_95.mp4', 'https://video.hu/thumb_95.jpg', '<iframe src="https://video.hu/video_95.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_96.mp4', 'https://video.hu/thumb_96.jpg', '<iframe src="https://video.hu/video_96.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_97.mp4', 'https://video.hu/thumb_97.jpg', '<iframe src="https://video.hu/video_97.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_98.mp4', 'https://video.hu/thumb_98.jpg', '<iframe src="https://video.hu/video_98.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_99.mp4', 'https://video.hu/thumb_99.jpg', '<iframe src="https://video.hu/video_99.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_100.mp4', 'https://video.hu/thumb_100.jpg', '<iframe src="https://video.hu/video_100.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_101.mp4', 'https://video.hu/thumb_101.jpg', '<iframe src="https://video.hu/video_101.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_102.mp4', 'https://video.hu/thumb_102.jpg', '<iframe src="https://video.hu/video_102.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_103.mp4', 'https://video.hu/thumb_103.jpg', '<iframe src="https://video.hu/video_103.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_104.mp4', 'https://video.hu/thumb_104.jpg', '<iframe src="https://video.hu/video_104.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_105.mp4', 'https://video.hu/thumb_105.jpg', '<iframe src="https://video.hu/video_105.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_106.mp4', 'https://video.hu/thumb_106.jpg', '<iframe src="https://video.hu/video_106.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_107.mp4', 'https://video.hu/thumb_107.jpg', '<iframe src="https://video.hu/video_107.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_108.mp4', 'https://video.hu/thumb_108.jpg', '<iframe src="https://video.hu/video_108.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_109.mp4', 'https://video.hu/thumb_109.jpg', '<iframe src="https://video.hu/video_109.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_110.mp4', 'https://video.hu/thumb_110.jpg', '<iframe src="https://video.hu/video_110.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_111.mp4', 'https://video.hu/thumb_111.jpg', '<iframe src="https://video.hu/video_111.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_112.mp4', 'https://video.hu/thumb_112.jpg', '<iframe src="https://video.hu/video_112.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_113.mp4', 'https://video.hu/thumb_113.jpg', '<iframe src="https://video.hu/video_113.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_114.mp4', 'https://video.hu/thumb_114.jpg', '<iframe src="https://video.hu/video_114.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_115.mp4', 'https://video.hu/thumb_115.jpg', '<iframe src="https://video.hu/video_115.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_116.mp4', 'https://video.hu/thumb_116.jpg', '<iframe src="https://video.hu/video_116.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_117.mp4', 'https://video.hu/thumb_117.jpg', '<iframe src="https://video.hu/video_117.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_118.mp4', 'https://video.hu/thumb_118.jpg', '<iframe src="https://video.hu/video_118.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_119.mp4', 'https://video.hu/thumb_119.jpg', '<iframe src="https://video.hu/video_119.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_120.mp4', 'https://video.hu/thumb_120.jpg', '<iframe src="https://video.hu/video_120.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_121.mp4', 'https://video.hu/thumb_121.jpg', '<iframe src="https://video.hu/video_121.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_122.mp4', 'https://video.hu/thumb_122.jpg', '<iframe src="https://video.hu/video_122.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_123.mp4', 'https://video.hu/thumb_123.jpg', '<iframe src="https://video.hu/video_123.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_124.mp4', 'https://video.hu/thumb_124.jpg', '<iframe src="https://video.hu/video_124.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_125.mp4', 'https://video.hu/thumb_125.jpg', '<iframe src="https://video.hu/video_125.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_126.mp4', 'https://video.hu/thumb_126.jpg', '<iframe src="https://video.hu/video_126.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_127.mp4', 'https://video.hu/thumb_127.jpg', '<iframe src="https://video.hu/video_127.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_128.mp4', 'https://video.hu/thumb_128.jpg', '<iframe src="https://video.hu/video_128.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_129.mp4', 'https://video.hu/thumb_129.jpg', '<iframe src="https://video.hu/video_129.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_130.mp4', 'https://video.hu/thumb_130.jpg', '<iframe src="https://video.hu/video_130.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_131.mp4', 'https://video.hu/thumb_131.jpg', '<iframe src="https://video.hu/video_131.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_132.mp4', 'https://video.hu/thumb_132.jpg', '<iframe src="https://video.hu/video_132.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_133.mp4', 'https://video.hu/thumb_133.jpg', '<iframe src="https://video.hu/video_133.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_134.mp4', 'https://video.hu/thumb_134.jpg', '<iframe src="https://video.hu/video_134.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_135.mp4', 'https://video.hu/thumb_135.jpg', '<iframe src="https://video.hu/video_135.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_136.mp4', 'https://video.hu/thumb_136.jpg', '<iframe src="https://video.hu/video_136.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_137.mp4', 'https://video.hu/thumb_137.jpg', '<iframe src="https://video.hu/video_137.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_138.mp4', 'https://video.hu/thumb_138.jpg', '<iframe src="https://video.hu/video_138.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_139.mp4', 'https://video.hu/thumb_139.jpg', '<iframe src="https://video.hu/video_139.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_140.mp4', 'https://video.hu/thumb_140.jpg', '<iframe src="https://video.hu/video_140.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_141.mp4', 'https://video.hu/thumb_141.jpg', '<iframe src="https://video.hu/video_141.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_142.mp4', 'https://video.hu/thumb_142.jpg', '<iframe src="https://video.hu/video_142.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_143.mp4', 'https://video.hu/thumb_143.jpg', '<iframe src="https://video.hu/video_143.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_144.mp4', 'https://video.hu/thumb_144.jpg', '<iframe src="https://video.hu/video_144.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_145.mp4', 'https://video.hu/thumb_145.jpg', '<iframe src="https://video.hu/video_145.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_146.mp4', 'https://video.hu/thumb_146.jpg', '<iframe src="https://video.hu/video_146.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_147.mp4', 'https://video.hu/thumb_147.jpg', '<iframe src="https://video.hu/video_147.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_148.mp4', 'https://video.hu/thumb_148.jpg', '<iframe src="https://video.hu/video_148.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_149.mp4', 'https://video.hu/thumb_149.jpg', '<iframe src="https://video.hu/video_149.mp4"></iframe>');


INSERT INTO VideoMetadata (video_url, miniatur_url, beagyazasi_kod)
VALUES ('https://video.hu/video_150.mp4', 'https://video.hu/thumb_150.jpg', '<iframe src="https://video.hu/video_150.mp4"></iframe>');




-- 5. Adatok beszúrása: Hozzaszolas
INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 2, 2, 'Nagyon tetszett a(z) 2. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 3, 3, 'Nagyon tetszett a(z) 3. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 4, 4, 'Nagyon tetszett a(z) 4. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 5, 5, 'Nagyon tetszett a(z) 5. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 6, 6, 'Nagyon tetszett a(z) 6. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 7, 7, 'Nagyon tetszett a(z) 7. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 8, 8, 'Nagyon tetszett a(z) 8. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 9, 9, 'Nagyon tetszett a(z) 9. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 10, 10, 'Nagyon tetszett a(z) 10. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 11, 11, 'Nagyon tetszett a(z) 11. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 12, 12, 'Nagyon tetszett a(z) 12. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 13, 13, 'Nagyon tetszett a(z) 13. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 14, 14, 'Nagyon tetszett a(z) 14. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 15, 15, 'Nagyon tetszett a(z) 15. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 16, 16, 'Nagyon tetszett a(z) 16. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 17, 17, 'Nagyon tetszett a(z) 17. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 18, 18, 'Nagyon tetszett a(z) 18. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 19, 19, 'Nagyon tetszett a(z) 19. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 20, 20, 'Nagyon tetszett a(z) 20. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 21, 21, 'Nagyon tetszett a(z) 21. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 22, 22, 'Nagyon tetszett a(z) 22. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 23, 23, 'Nagyon tetszett a(z) 23. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 24, 24, 'Nagyon tetszett a(z) 24. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 25, 25, 'Nagyon tetszett a(z) 25. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 26, 26, 'Nagyon tetszett a(z) 26. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 27, 27, 'Nagyon tetszett a(z) 27. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 28, 28, 'Nagyon tetszett a(z) 28. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 29, 29, 'Nagyon tetszett a(z) 29. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 30, 30, 'Nagyon tetszett a(z) 30. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 31, 31, 'Nagyon tetszett a(z) 31. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 32, 32, 'Nagyon tetszett a(z) 32. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 33, 33, 'Nagyon tetszett a(z) 33. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 34, 34, 'Nagyon tetszett a(z) 34. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 35, 35, 'Nagyon tetszett a(z) 35. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 36, 36, 'Nagyon tetszett a(z) 36. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 37, 37, 'Nagyon tetszett a(z) 37. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 38, 38, 'Nagyon tetszett a(z) 38. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 39, 39, 'Nagyon tetszett a(z) 39. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 40, 40, 'Nagyon tetszett a(z) 40. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 41, 41, 'Nagyon tetszett a(z) 41. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 42, 42, 'Nagyon tetszett a(z) 42. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 43, 43, 'Nagyon tetszett a(z) 43. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 44, 44, 'Nagyon tetszett a(z) 44. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 45, 45, 'Nagyon tetszett a(z) 45. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 46, 46, 'Nagyon tetszett a(z) 46. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 47, 47, 'Nagyon tetszett a(z) 47. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 48, 48, 'Nagyon tetszett a(z) 48. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 49, 49, 'Nagyon tetszett a(z) 49. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 50, 50, 'Nagyon tetszett a(z) 50. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 51, 51, 'Nagyon tetszett a(z) 51. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 52, 52, 'Nagyon tetszett a(z) 52. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 53, 53, 'Nagyon tetszett a(z) 53. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 54, 54, 'Nagyon tetszett a(z) 54. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 55, 55, 'Nagyon tetszett a(z) 55. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 56, 56, 'Nagyon tetszett a(z) 56. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 57, 57, 'Nagyon tetszett a(z) 57. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 58, 58, 'Nagyon tetszett a(z) 58. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 59, 59, 'Nagyon tetszett a(z) 59. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 60, 60, 'Nagyon tetszett a(z) 60. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 61, 61, 'Nagyon tetszett a(z) 61. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 62, 62, 'Nagyon tetszett a(z) 62. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 63, 63, 'Nagyon tetszett a(z) 63. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 64, 64, 'Nagyon tetszett a(z) 64. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 65, 65, 'Nagyon tetszett a(z) 65. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 66, 66, 'Nagyon tetszett a(z) 66. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 67, 67, 'Nagyon tetszett a(z) 67. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 68, 68, 'Nagyon tetszett a(z) 68. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 69, 69, 'Nagyon tetszett a(z) 69. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 70, 70, 'Nagyon tetszett a(z) 70. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 71, 71, 'Nagyon tetszett a(z) 71. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 72, 72, 'Nagyon tetszett a(z) 72. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 73, 73, 'Nagyon tetszett a(z) 73. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 74, 74, 'Nagyon tetszett a(z) 74. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 75, 75, 'Nagyon tetszett a(z) 75. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 76, 76, 'Nagyon tetszett a(z) 76. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 77, 77, 'Nagyon tetszett a(z) 77. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 78, 78, 'Nagyon tetszett a(z) 78. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 79, 79, 'Nagyon tetszett a(z) 79. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 80, 80, 'Nagyon tetszett a(z) 80. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 81, 81, 'Nagyon tetszett a(z) 81. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 82, 82, 'Nagyon tetszett a(z) 82. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 83, 83, 'Nagyon tetszett a(z) 83. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 84, 84, 'Nagyon tetszett a(z) 84. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 85, 85, 'Nagyon tetszett a(z) 85. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 86, 86, 'Nagyon tetszett a(z) 86. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 87, 87, 'Nagyon tetszett a(z) 87. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 88, 88, 'Nagyon tetszett a(z) 88. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 89, 89, 'Nagyon tetszett a(z) 89. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 90, 90, 'Nagyon tetszett a(z) 90. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 91, 91, 'Nagyon tetszett a(z) 91. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 92, 92, 'Nagyon tetszett a(z) 92. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 93, 93, 'Nagyon tetszett a(z) 93. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 94, 94, 'Nagyon tetszett a(z) 94. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 95, 95, 'Nagyon tetszett a(z) 95. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 96, 96, 'Nagyon tetszett a(z) 96. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 97, 97, 'Nagyon tetszett a(z) 97. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 98, 98, 'Nagyon tetszett a(z) 98. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 99, 99, 'Nagyon tetszett a(z) 99. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 100, 100, 'Nagyon tetszett a(z) 100. videó!', SYSTIMESTAMP
);

INSERT INTO Hozzaszolas (
    hozzaszolas_id, felhasznalo_id, video_id, hozzaszolas_szoveg, letrehozas_datum
) VALUES (
    hozzaszolas_seq.NEXTVAL, 101, 101, 'Nagyon tetszett a(z) 101. videó!', SYSTIMESTAMP
);


-- 6. Adatok beszúrása: Cimke
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 1');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 2');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 3');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 4');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 5');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 6');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 7');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 8');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 9');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 10');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 11');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 12');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 13');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 14');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 15');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 16');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 17');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 18');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 19');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 20');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 21');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 22');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 23');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 24');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 25');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 26');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 27');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 28');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 29');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 30');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 31');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 32');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 33');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 34');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 35');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 36');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 37');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 38');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 39');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 40');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 41');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 42');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 43');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 44');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 45');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 46');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 47');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 48');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 49');
INSERT INTO Cimke (cimke_id, nev) VALUES (cimke_seq.NEXTVAL, 'Címke 50');

-- 7. Adatok beszúrása: VideoCimke
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (1, 2);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (1, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (2, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (2, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (2, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (3, 4);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (4, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (4, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (5, 6);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (5, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (5, 16);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (6, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (7, 8);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (7, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (8, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (8, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (8, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (9, 10);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (10, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (10, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (11, 12);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (11, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (11, 34);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (12, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (13, 14);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (13, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (14, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (14, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (14, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (15, 16);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (16, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (16, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (17, 18);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (17, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (17, 2);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (18, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (19, 20);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (19, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (20, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (20, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (20, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (21, 22);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (22, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (22, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (23, 24);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (23, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (23, 20);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (24, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (25, 26);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (25, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (26, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (26, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (26, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (27, 28);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (28, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (28, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (29, 30);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (29, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (29, 38);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (30, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (31, 32);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (31, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (32, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (32, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (32, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (33, 34);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (34, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (34, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (35, 36);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (35, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (35, 6);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (36, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (37, 38);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (37, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (38, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (38, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (38, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (39, 40);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (40, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (40, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (41, 42);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (41, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (41, 24);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (42, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (43, 44);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (43, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (44, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (44, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (44, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (45, 46);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (46, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (46, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (47, 48);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (47, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (47, 42);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (48, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (49, 50);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (49, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (50, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (50, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (50, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (51, 2);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (52, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (52, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (53, 4);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (53, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (53, 10);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (54, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (55, 6);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (55, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (56, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (56, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (56, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (57, 8);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (58, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (58, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (59, 10);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (59, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (59, 28);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (60, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (61, 12);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (61, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (62, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (62, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (62, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (63, 14);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (64, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (64, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (65, 16);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (65, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (65, 46);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (66, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (67, 18);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (67, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (68, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (68, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (68, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (69, 20);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (70, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (70, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (71, 22);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (71, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (71, 14);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (72, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (73, 24);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (73, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (74, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (74, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (74, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (75, 26);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (76, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (76, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (77, 28);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (77, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (77, 32);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (78, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (79, 30);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (79, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (80, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (80, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (80, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (81, 32);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (82, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (82, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (83, 34);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (83, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (83, 50);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (84, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (85, 36);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (85, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (86, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (86, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (86, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (87, 38);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (88, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (88, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (89, 40);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (89, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (89, 18);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (90, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (91, 42);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (91, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (92, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (92, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (92, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (93, 44);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (94, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (94, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (95, 46);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (95, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (95, 36);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (96, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (97, 48);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (97, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (98, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (98, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (98, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (99, 50);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (100, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (100, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (101, 2);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (101, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (101, 4);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (102, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (103, 4);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (103, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (104, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (104, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (104, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (105, 6);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (106, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (106, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (107, 8);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (107, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (107, 22);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (108, 9);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (109, 10);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (109, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (110, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (110, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (110, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (111, 12);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (112, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (112, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (113, 14);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (113, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (113, 40);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (114, 15);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (115, 16);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (115, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (116, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (116, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (116, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (117, 18);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (118, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (118, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (119, 20);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (119, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (119, 8);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (120, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (121, 22);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (121, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (122, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (122, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (122, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (123, 24);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (124, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (124, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (125, 26);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (125, 1);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (125, 26);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (126, 27);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (127, 28);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (127, 5);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (128, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (128, 7);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (128, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (129, 30);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (130, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (130, 11);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (131, 32);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (131, 13);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (131, 44);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (132, 33);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (133, 34);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (133, 17);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (134, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (134, 19);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (134, 3);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (135, 36);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (136, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (136, 23);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (137, 38);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (137, 25);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (137, 12);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (138, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (139, 40);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (139, 29);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (140, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (140, 31);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (140, 21);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (141, 42);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (142, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (142, 35);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (143, 44);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (143, 37);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (143, 30);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (144, 45);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (145, 46);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (145, 41);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (146, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (146, 43);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (146, 39);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (147, 48);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (148, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (148, 47);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (149, 50);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (149, 49);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (149, 48);
INSERT INTO VideoCimke (video_id, cimke_id) VALUES (150, 1);


-- 8. Adatok beszúrása: LejatszasiLista

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 1', 2, 0, SYSTIMESTAMP
);



-- 9. Adatok beszúrása: LejatszasiListaVideo
INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 2', 3, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (2, 3, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (2, 5, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (2, 7, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 3', 4, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (3, 4, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (3, 7, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (3, 10, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 4', 5, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (4, 5, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (4, 9, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (4, 13, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 5', 6, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (5, 6, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (5, 11, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (5, 16, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 6', 7, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (6, 7, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (6, 13, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (6, 19, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 7', 8, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (7, 8, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (7, 15, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (7, 22, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 8', 9, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (8, 9, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (8, 17, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (8, 25, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 9', 10, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (9, 10, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (9, 19, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (9, 28, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 10', 11, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (10, 11, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (10, 21, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (10, 31, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 11', 12, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (11, 12, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (11, 23, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (11, 34, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 12', 13, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (12, 13, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (12, 25, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (12, 37, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 13', 14, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (13, 14, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (13, 27, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (13, 40, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 14', 15, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (14, 15, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (14, 29, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (14, 43, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 15', 16, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (15, 16, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (15, 31, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (15, 46, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 16', 17, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (16, 17, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (16, 33, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (16, 49, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 17', 18, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (17, 18, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (17, 35, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (17, 52, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 18', 19, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (18, 19, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (18, 37, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (18, 55, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 19', 20, 0, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (19, 20, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (19, 39, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (19, 58, 3, SYSTIMESTAMP);

INSERT INTO LejatszasiLista (
    lista_id, nev, felhasznalo_id, publikus, letrehozas_datum
) VALUES (
    lejatszasilista_seq.NEXTVAL, 'Lista 20', 21, 1, SYSTIMESTAMP
);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (20, 21, 1, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (20, 41, 2, SYSTIMESTAMP);
INSERT INTO LejatszasiListaVideo (lista_id, video_id, pozicio, hozzaadas_datum) VALUES (20, 61, 3, SYSTIMESTAMP);

-- 10. Adatok beszúrása: Kedvencek
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (2, 4, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (3, 7, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (4, 10, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (5, 13, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (6, 16, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (7, 19, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (8, 22, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (9, 25, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (10, 28, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (11, 31, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (12, 34, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (13, 37, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (14, 40, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (15, 43, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (16, 46, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (17, 49, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (18, 52, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (19, 55, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (20, 58, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (21, 61, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (22, 64, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (23, 67, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (24, 70, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (25, 73, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (26, 76, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (27, 79, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (28, 82, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (29, 85, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (30, 88, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (31, 91, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (32, 94, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (33, 97, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (34, 100, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (35, 103, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (36, 106, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (37, 109, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (38, 112, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (39, 115, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (40, 118, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (41, 121, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (42, 124, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (43, 127, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (44, 130, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (45, 133, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (46, 136, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (47, 139, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (48, 142, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (49, 145, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (50, 148, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (51, 1, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (52, 4, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (53, 7, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (54, 10, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (55, 13, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (56, 16, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (57, 19, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (58, 22, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (59, 25, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (60, 28, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (61, 31, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (62, 34, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (63, 37, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (64, 40, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (65, 43, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (66, 46, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (67, 49, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (68, 52, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (69, 55, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (70, 58, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (71, 61, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (72, 64, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (73, 67, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (74, 70, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (75, 73, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (76, 76, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (77, 79, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (78, 82, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (79, 85, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (80, 88, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (81, 91, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (82, 94, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (83, 97, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (84, 100, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (85, 103, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (86, 106, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (87, 109, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (88, 112, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (89, 115, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (90, 118, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (91, 121, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (92, 124, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (93, 127, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (94, 130, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (95, 133, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (96, 136, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (97, 139, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (98, 142, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (99, 145, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (100, 148, SYSTIMESTAMP);
INSERT INTO Kedvencek (felhasznalo_id, video_id, hozzaadas_datum) VALUES (101, 1, SYSTIMESTAMP);


-- 11. Adatok beszúrása: Megtekintes
INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 2, 17, SYSTIMESTAMP, 201
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 3, 17, SYSTIMESTAMP, 201
);
COMMIT;

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 3, 18, SYSTIMESTAMP, 202
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 4, 19, SYSTIMESTAMP, 203
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 5, 20, SYSTIMESTAMP, 204
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 6, 21, SYSTIMESTAMP, 205
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 7, 22, SYSTIMESTAMP, 206
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 8, 23, SYSTIMESTAMP, 207
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 9, 24, SYSTIMESTAMP, 208
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 10, 25, SYSTIMESTAMP, 209
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 11, 26, SYSTIMESTAMP, 210
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 12, 27, SYSTIMESTAMP, 211
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 13, 28, SYSTIMESTAMP, 212
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 14, 29, SYSTIMESTAMP, 213
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 15, 30, SYSTIMESTAMP, 214
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 16, 31, SYSTIMESTAMP, 215
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 17, 32, SYSTIMESTAMP, 216
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 18, 33, SYSTIMESTAMP, 217
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 19, 34, SYSTIMESTAMP, 218
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 20, 35, SYSTIMESTAMP, 219
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 21, 36, SYSTIMESTAMP, 220
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 22, 37, SYSTIMESTAMP, 221
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 23, 38, SYSTIMESTAMP, 222
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 24, 39, SYSTIMESTAMP, 223
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 25, 40, SYSTIMESTAMP, 224
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 26, 41, SYSTIMESTAMP, 225
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 27, 42, SYSTIMESTAMP, 226
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 28, 43, SYSTIMESTAMP, 227
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 29, 44, SYSTIMESTAMP, 228
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 30, 45, SYSTIMESTAMP, 229
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 31, 46, SYSTIMESTAMP, 230
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 32, 47, SYSTIMESTAMP, 231
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 33, 48, SYSTIMESTAMP, 232
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 34, 49, SYSTIMESTAMP, 233
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 35, 50, SYSTIMESTAMP, 234
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 36, 51, SYSTIMESTAMP, 235
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 37, 52, SYSTIMESTAMP, 236
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 38, 53, SYSTIMESTAMP, 237
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 39, 54, SYSTIMESTAMP, 238
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 40, 55, SYSTIMESTAMP, 239
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 41, 56, SYSTIMESTAMP, 240
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 42, 57, SYSTIMESTAMP, 241
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 43, 58, SYSTIMESTAMP, 242
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 44, 59, SYSTIMESTAMP, 243
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 45, 60, SYSTIMESTAMP, 244
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 46, 61, SYSTIMESTAMP, 245
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 47, 62, SYSTIMESTAMP, 246
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 48, 63, SYSTIMESTAMP, 247
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 49, 64, SYSTIMESTAMP, 248
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 50, 65, SYSTIMESTAMP, 249
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 51, 66, SYSTIMESTAMP, 250
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 52, 67, SYSTIMESTAMP, 251
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 53, 68, SYSTIMESTAMP, 252
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 54, 69, SYSTIMESTAMP, 253
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 55, 70, SYSTIMESTAMP, 254
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 56, 71, SYSTIMESTAMP, 255
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 57, 72, SYSTIMESTAMP, 256
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 58, 73, SYSTIMESTAMP, 257
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 59, 74, SYSTIMESTAMP, 258
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 60, 75, SYSTIMESTAMP, 259
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 61, 76, SYSTIMESTAMP, 260
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 62, 77, SYSTIMESTAMP, 261
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 63, 78, SYSTIMESTAMP, 262
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 64, 79, SYSTIMESTAMP, 263
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 65, 80, SYSTIMESTAMP, 264
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 66, 81, SYSTIMESTAMP, 265
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 67, 82, SYSTIMESTAMP, 266
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 68, 83, SYSTIMESTAMP, 267
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 69, 84, SYSTIMESTAMP, 268
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 70, 85, SYSTIMESTAMP, 269
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 71, 86, SYSTIMESTAMP, 270
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 72, 87, SYSTIMESTAMP, 271
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 73, 88, SYSTIMESTAMP, 272
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 74, 89, SYSTIMESTAMP, 273
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 75, 90, SYSTIMESTAMP, 274
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 76, 91, SYSTIMESTAMP, 275
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 77, 92, SYSTIMESTAMP, 276
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 78, 93, SYSTIMESTAMP, 277
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 79, 94, SYSTIMESTAMP, 278
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 80, 95, SYSTIMESTAMP, 279
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 81, 96, SYSTIMESTAMP, 280
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 82, 97, SYSTIMESTAMP, 281
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 83, 98, SYSTIMESTAMP, 282
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 84, 99, SYSTIMESTAMP, 283
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 85, 100, SYSTIMESTAMP, 284
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 86, 101, SYSTIMESTAMP, 285
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 87, 102, SYSTIMESTAMP, 286
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 88, 103, SYSTIMESTAMP, 287
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 89, 104, SYSTIMESTAMP, 288
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 90, 105, SYSTIMESTAMP, 289
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 91, 106, SYSTIMESTAMP, 290
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 92, 107, SYSTIMESTAMP, 291
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 93, 108, SYSTIMESTAMP, 292
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 94, 109, SYSTIMESTAMP, 293
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 95, 110, SYSTIMESTAMP, 294
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 96, 111, SYSTIMESTAMP, 295
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 97, 112, SYSTIMESTAMP, 296
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 98, 113, SYSTIMESTAMP, 297
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 99, 114, SYSTIMESTAMP, 298
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 100, 115, SYSTIMESTAMP, 299
);

INSERT INTO Megtekintes (
    megtekintes_id, video_id, felhasznalo_id, megtekintes_datum, megtekintes_hossz
) VALUES (
    megtekintes_seq.NEXTVAL, 101, 116, SYSTIMESTAMP, 300
);

-- 12. Adatok beszúrása: Ajanlasok
INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 6, 5, 0.51, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 7, 6, 0.52, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 8, 7, 0.53, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 9, 8, 0.54, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 10, 9, 0.55, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 11, 10, 0.56, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 12, 11, 0.57, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 13, 12, 0.58, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 14, 13, 0.59, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 15, 14, 0.6, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 16, 15, 0.61, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 17, 16, 0.62, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 18, 17, 0.63, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 19, 18, 0.64, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 20, 19, 0.65, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 21, 20, 0.66, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 22, 21, 0.67, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 23, 22, 0.68, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 24, 23, 0.69, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 25, 24, 0.7, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 26, 25, 0.71, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 27, 26, 0.72, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 28, 27, 0.73, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 29, 28, 0.74, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 30, 29, 0.75, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 31, 30, 0.76, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 32, 31, 0.77, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 33, 32, 0.78, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 34, 33, 0.79, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 35, 34, 0.8, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 36, 35, 0.81, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 37, 36, 0.82, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 38, 37, 0.83, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 39, 38, 0.84, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 40, 39, 0.85, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 41, 40, 0.86, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 42, 41, 0.87, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 43, 42, 0.88, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 44, 43, 0.89, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 45, 44, 0.9, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 46, 45, 0.91, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 47, 46, 0.92, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 48, 47, 0.93, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 49, 48, 0.94, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 50, 49, 0.95, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 51, 50, 0.96, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 52, 51, 0.97, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 53, 52, 0.98, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 54, 53, 0.99, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 55, 54, 0.5, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 56, 55, 0.51, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 57, 56, 0.52, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 58, 57, 0.53, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 59, 58, 0.54, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 60, 59, 0.55, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 61, 60, 0.56, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 62, 61, 0.57, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 63, 62, 0.58, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 64, 63, 0.59, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 65, 64, 0.6, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 66, 65, 0.61, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 67, 66, 0.62, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 68, 67, 0.63, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 69, 68, 0.64, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 70, 69, 0.65, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 71, 70, 0.66, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 72, 71, 0.67, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 73, 72, 0.68, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 74, 73, 0.69, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 75, 74, 0.7, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 76, 75, 0.71, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 77, 76, 0.72, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 78, 77, 0.73, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 79, 78, 0.74, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 80, 79, 0.75, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 81, 80, 0.76, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 82, 81, 0.77, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 83, 82, 0.78, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 84, 83, 0.79, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 85, 84, 0.8, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 86, 85, 0.81, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 87, 86, 0.82, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 88, 87, 0.83, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 89, 88, 0.84, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 90, 89, 0.85, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 91, 90, 0.86, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 92, 91, 0.87, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 93, 92, 0.88, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 94, 93, 0.89, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 95, 94, 0.9, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 96, 95, 0.91, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 97, 96, 0.92, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 98, 97, 0.93, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 99, 98, 0.94, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 100, 99, 0.95, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 101, 100, 0.96, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 102, 101, 0.97, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 103, 102, 0.98, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 104, 103, 0.99, SYSTIMESTAMP
);

INSERT INTO Ajanlasok (
    ajanlas_id, felhasznalo_id, video_id, ajanlas_erosseg, ajanlas_datum
) VALUES (
    ajanlas_seq.NEXTVAL, 105, 104, 0.5, SYSTIMESTAMP
);


-- 13. Adatok beszúrása: VideoKategoria

INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (1, 2);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (2, 3);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (3, 4);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (3, 9);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (4, 5);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (5, 6);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (6, 7);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (6, 12);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (7, 8);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (8, 9);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (9, 10);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (9, 15);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (10, 11);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (11, 12);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (12, 13);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (12, 18);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (13, 14);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (14, 15);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (15, 16);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (15, 21);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (16, 17);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (17, 18);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (18, 19);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (18, 24);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (19, 20);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (20, 21);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (21, 22);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (21, 27);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (22, 23);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (23, 24);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (24, 25);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (24, 30);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (25, 26);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (26, 27);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (27, 28);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (27, 33);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (28, 29);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (29, 30);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (30, 31);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (30, 36);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (31, 32);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (32, 33);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (33, 34);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (33, 39);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (34, 35);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (35, 36);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (36, 37);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (36, 42);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (37, 38);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (38, 39);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (39, 40);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (39, 45);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (40, 41);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (41, 42);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (42, 43);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (42, 48);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (43, 44);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (44, 45);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (45, 46);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (45, 1);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (46, 47);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (47, 48);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (48, 49);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (48, 4);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (49, 50);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (50, 1);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (51, 2);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (51, 7);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (52, 3);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (53, 4);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (54, 5);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (54, 10);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (55, 6);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (56, 7);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (57, 8);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (57, 13);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (58, 9);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (59, 10);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (60, 11);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (60, 16);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (61, 12);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (62, 13);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (63, 14);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (63, 19);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (64, 15);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (65, 16);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (66, 17);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (66, 22);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (67, 18);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (68, 19);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (69, 20);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (69, 25);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (70, 21);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (71, 22);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (72, 23);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (72, 28);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (73, 24);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (74, 25);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (75, 26);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (75, 31);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (76, 27);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (77, 28);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (78, 29);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (78, 34);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (79, 30);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (80, 31);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (81, 32);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (81, 37);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (82, 33);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (83, 34);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (84, 35);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (84, 40);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (85, 36);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (86, 37);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (87, 38);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (87, 43);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (88, 39);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (89, 40);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (90, 41);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (90, 46);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (91, 42);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (92, 43);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (93, 44);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (93, 49);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (94, 45);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (95, 46);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (96, 47);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (96, 2);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (97, 48);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (98, 49);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (99, 50);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (99, 5);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (100, 1);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (101, 2);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (102, 3);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (102, 8);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (103, 4);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (104, 5);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (105, 6);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (105, 11);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (106, 7);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (107, 8);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (108, 9);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (108, 14);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (109, 10);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (110, 11);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (111, 12);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (111, 17);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (112, 13);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (113, 14);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (114, 15);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (114, 20);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (115, 16);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (116, 17);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (117, 18);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (117, 23);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (118, 19);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (119, 20);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (120, 21);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (120, 26);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (121, 22);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (122, 23);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (123, 24);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (123, 29);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (124, 25);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (125, 26);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (126, 27);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (126, 32);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (127, 28);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (128, 29);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (129, 30);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (129, 35);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (130, 31);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (131, 32);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (132, 33);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (132, 38);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (133, 34);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (134, 35);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (135, 36);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (135, 41);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (136, 37);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (137, 38);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (138, 39);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (138, 44);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (139, 40);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (140, 41);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (141, 42);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (141, 47);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (142, 43);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (143, 44);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (144, 45);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (144, 50);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (145, 46);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (146, 47);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (147, 48);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (147, 3);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (148, 49);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (149, 50);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (150, 1);
INSERT INTO VideoKategoria (video_id, kategoria_id) VALUES (150, 6);

COMMIT;




